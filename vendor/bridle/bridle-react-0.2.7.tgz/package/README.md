# `@bridle/react`

React hooks and reference components for Bridle Host Apps.

## Safety components

`ProposalCard`, `ProposalList`, `ApprovalCard`, and the Egress-bearing
`TurnReceiptFooter` are official-face trusted chrome. They deliberately have no
headless or safety-override props. Proposal action safety derives from the
core-produced `ProposalPreview`; change safety derives from the durable
`Proposal` record.

Safety-critical visibility, badges, face tone, and irreversibility text use
inline styles so ordinary Host App stylesheets cannot accidentally hide or
soften them. A Host App can still act maliciously with `!important`, DOM
removal, or renderer tampering. A React library cannot defend against its own
host process; Bridle's contract prevents accidental or API-facilitated
softening, not a hostile Host App.

Non-safety presentation components and hooks remain available for Host App
reskinning.
